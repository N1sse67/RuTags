package me.rutags;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.geysermc.cumulus.form.CustomForm;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Формы для игроков с Bedrock через Floodgate. */
public final class BedrockHook {

    private final TagsPlugin plugin;

    public BedrockHook(TagsPlugin plugin) {
        this.plugin = plugin;
        FloodgateApi.getInstance();
    }

    public boolean isBedrock(UUID id) {
        return FloodgateApi.getInstance().isFloodgatePlayer(id);
    }

    private static String c(String text) {
        String s = text.replace('&', '§').replaceAll("(?i)§[0-9a-fk-or]", "");
        return "§0" + s;
    }

    /** Выдача тега: выбираем игрока и тег в одной форме. */
    public void openGive(Player admin) {
        List<Tag> tags = plugin.manager().all();
        if (tags.isEmpty()) {
            admin.sendMessage(plugin.text("list-empty"));
            return;
        }
        List<String> players = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) players.add(p.getName());
        if (players.isEmpty()) return;

        List<String> tagNames = new ArrayList<>();
        for (Tag t : tags) tagNames.add(c(t.name));
        tagNames.add(c(plugin.raw("form-give-none")));

        CustomForm.Builder form = CustomForm.builder()
                .title(c(plugin.raw("form-give-title")))
                .dropdown(c(plugin.raw("form-give-player")), players.toArray(new String[0]))
                .dropdown(c(plugin.raw("form-give-tag")), tagNames.toArray(new String[0]))
                .input(c(plugin.raw("form-give-other")), "", "");
        form.validResultHandler(response -> {
            int pi = response.asDropdown(0);
            int ti = response.asDropdown(1);
            String other = response.asInput(2);
            Bukkit.getScheduler().runTask(plugin, () -> {
                org.bukkit.OfflinePlayer target = null;
                if (other != null && !other.isBlank()) {
                    target = Bukkit.getPlayerExact(other.trim());
                    if (target == null) target = Bukkit.getOfflinePlayerIfCached(other.trim());
                    if (target == null) {
                        admin.sendMessage(plugin.msg("player-not-found", "%player%", other.trim()));
                        return;
                    }
                } else if (pi >= 0 && pi < players.size()) {
                    target = Bukkit.getPlayerExact(players.get(pi));
                    if (target == null) {
                        admin.sendMessage(plugin.msg("player-not-found", "%player%", players.get(pi)));
                        return;
                    }
                }
                if (target == null) return;
                String targetName = String.valueOf(target.getName());
                if (ti >= 0 && ti < tags.size()) {
                    Tag tag = plugin.manager().get(tags.get(ti).name);
                    if (tag == null) {
                        admin.sendMessage(plugin.msg("not-found", "%tag%", tags.get(ti).name));
                        return;
                    }
                    plugin.manager().give(target, tag);
                    admin.sendMessage(plugin.msg("given", "%player%", targetName,
                            "%preview%", plugin.manager().preview(tag)));
                } else {
                    boolean had = plugin.manager().take(target);
                    admin.sendMessage(plugin.msg(had ? "removed" : "has-no-tag", "%player%", targetName));
                }
            });
        });
        FloodgateApi.getInstance().sendForm(admin.getUniqueId(), form.build());
    }

    /** Выбор цвета: кнопки с названиями цветов, жирный, свой цвет. */
    public void openColors(Player player, String name, boolean bold) {
        SimpleForm.Builder form = SimpleForm.builder()
                .title(c(name))
                .content(c(plugin.raw("form-hint")));
        form.button(c(plugin.raw(bold ? "form-bold-on" : "form-bold-off")));
        for (String[] col : ColorUtil.PALETTE) form.button(c(col[1]));
        form.button(c(plugin.raw("form-custom")));
        form.button(c(plugin.raw("form-cancel")));

        int count = ColorUtil.PALETTE.length;
        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (id == 0) {
                    openColors(player, name, !bold);
                } else if (id >= 1 && id <= count) {
                    plugin.finish(player, name, "&" + ColorUtil.PALETTE[id - 1][0] + (bold ? "&l" : ""));
                } else if (id == count + 1) {
                    openCustom(player, name, bold);
                }
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }

    /** Свой цвет: поле для ввода и переключатель «жирный». */
    public void openCustom(Player player, String name, boolean bold) {
        CustomForm.Builder form = CustomForm.builder()
                .title(c(name))
                .input(c(plugin.raw("form-input")).replace("{AMP}", "&"), "#FF8800", plugin.getConfig().getString("anvil-start-text", "#FFAA00"))
                .toggle(c(plugin.raw("form-input-bold")), bold);
        form.validResultHandler(response -> {
            String input = response.asInput(0);
            boolean b = response.asToggle(1);
            Bukkit.getScheduler().runTask(plugin, () -> {
                ColorUtil.Result res = ColorUtil.resolve(input, plugin.getConfig().getInt("max-length", 16));
                if (res == null) {
                    player.sendMessage(plugin.msg("anvil-bad", "%max%", String.valueOf(plugin.getConfig().getInt("max-length", 16))));
                    return;
                }
                String color = res.color();
                String display = res.display();
                if (b) {
                    if (display == null && !color.contains("&l")) color += "&l";
                    if (display != null) display = display.replaceAll("(&#[0-9a-f]{6}|&[0-9a-f])", "$1&l");
                }
                plugin.finish(player, name, color, display);
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }
}
