package me.rutags;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class TagsPlugin extends JavaPlugin {

    /** Игрок вводит свой цвет в наковальне: что создаём. */
    public record AnvilSession(String name) {}

    private TagManager manager;
    private BedrockHook bedrock;
    private final Map<UUID, AnvilSession> anvils = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        manager = new TagManager(this);
        manager.load();
        getServer().getPluginManager().registerEvents(new TagListener(this), this);

        TagCommand handler = new TagCommand(this);
        PluginCommand command = getCommand("rutag");
        if (command != null) {
            command.setExecutor(handler);
            command.setTabCompleter(handler);
        }
        Bukkit.getScheduler().runTaskLater(this, () -> manager.applyAll(), 20L);
        Bukkit.getScheduler().runTaskTimer(this, () -> manager.tick(), 100L, 100L);
        getLogger().info("RuTags включён. Тегов: " + manager.all().size());
    }

    @Override
    public void onDisable() {
        if (manager != null) {
            manager.save();
            manager.cleanup();
        }
    }

    public void reload() {
        reloadConfig();
        manager.load();
        manager.applyAll();
    }

    public TagManager manager() {
        return manager;
    }

    public Map<UUID, AnvilSession> anvils() {
        return anvils;
    }

    public BedrockHook bedrock() {
        if (bedrock == null && getServer().getPluginManager().isPluginEnabled("floodgate")) {
            try {
                bedrock = new BedrockHook(this);
            } catch (Throwable t) {
                getLogger().warning("Floodgate найден, но подключиться не удалось: " + t);
            }
        }
        return bedrock;
    }

    public boolean isBedrock(Player player) {
        BedrockHook hook = bedrock();
        return hook != null && hook.isBedrock(player.getUniqueId());
    }

    // ---------- сообщения ----------

    public String raw(String key) {
        return getConfig().getString("messages." + key, key);
    }

    public static String fill(String text, String... replacements) {
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            text = text.replace(replacements[i], replacements[i + 1]);
        }
        return text;
    }

    /** {AMP} в настройках превращается в символ &, чтобы показывать примеры кодов, а не применять их. */
    private static Component amp(Component c) {
        return c.replaceText(net.kyori.adventure.text.TextReplacementConfig.builder()
                .matchLiteral("{AMP}").replacement("&").build());
    }

    public Component msg(String key, String... replacements) {
        return amp(TagManager.LEGACY.deserialize(raw("prefix") + fill(raw(key), replacements)));
    }

    public Component text(String key, String... replacements) {
        return amp(TagManager.LEGACY.deserialize(fill(raw(key), replacements)));
    }

    // ---------- создание тега ----------

    /** Открыть выбор цвета (форма для Bedrock или меню-сундук для Java). */
    public void startCreate(Player admin, String name) {
        if (isBedrock(admin)) {
            bedrock().openColors(admin, name, false);
        } else {
            ColorMenu.open(this, admin, name, false);
        }
    }

    /** Цвет выбран: создать или обновить тег. */
    public void finish(Player admin, String name, String color) {
        finish(admin, name, color, null);
    }

    /** То же, но display — готовый разноцветный текст (или null для обычного одного цвета). */
    public void finish(Player admin, String name, String color, String display) {
        boolean existed = manager.createOrUpdate(name, color, display);
        admin.sendMessage(msg(existed ? "recolored" : "created", "%preview%", manager.preview(manager.get(name))));
    }

    /** Открыть наковальню для ввода своего цвета. */
    public void openAnvil(Player admin, String name) {
        anvils.put(admin.getUniqueId(), new AnvilSession(name));
        org.bukkit.inventory.InventoryView view = org.bukkit.inventory.MenuType.ANVIL.create(admin,
                Component.text(raw("anvil-title")));
        org.bukkit.inventory.ItemStack paper = new org.bukkit.inventory.ItemStack(org.bukkit.Material.PAPER);
        org.bukkit.inventory.meta.ItemMeta meta = paper.getItemMeta();
        meta.displayName(Component.text(getConfig().getString("anvil-start-text", "#FFAA00")));
        paper.setItemMeta(meta);
        view.getTopInventory().setItem(0, paper);
        admin.openInventory(view);
        admin.sendMessage(text("anvil-hint"));
    }
}
