package me.rutags;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public final class TagCommand implements CommandExecutor, TabCompleter {

    private final TagsPlugin plugin;

    public TagCommand(TagsPlugin plugin) {
        this.plugin = plugin;
    }

    private static String rest(String[] args, int from) {
        return String.join(" ", Arrays.copyOfRange(args, from, args.length)).trim();
    }

    private OfflinePlayer findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online;
        OfflinePlayer cached = Bukkit.getOfflinePlayerIfCached(name);
        return cached;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("rutags.use")) {
            sender.sendMessage(plugin.msg("no-permission"));
            return true;
        }
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        TagManager tm = plugin.manager();

        switch (sub) {
            case "reload" -> {
                plugin.reload();
                sender.sendMessage(plugin.msg("reloaded"));
            }
            case "create", "создать", "цвет", "color" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(plugin.msg("players-only"));
                    return true;
                }
                String name = rest(args, 1).replaceAll("(?i)[&§][0-9a-fk-or]", "").trim();
                if (args.length < 2) {
                    sender.sendMessage(plugin.msg("usage-create"));
                    return true;
                }
                int max = plugin.getConfig().getInt("max-length", 16);
                if (name.isEmpty() || name.length() > max) {
                    sender.sendMessage(plugin.msg("name-bad", "%max%", String.valueOf(max)));
                    return true;
                }
                Tag existing = tm.get(name);
                plugin.startCreate(player, existing != null ? existing.name : name);
            }
            case "give", "выдать", "надеть" -> {
                if (args.length < 3) {
                    sender.sendMessage(plugin.msg("usage-give"));
                    return true;
                }
                OfflinePlayer target = findPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(plugin.msg("player-not-found", "%player%", args[1]));
                    return true;
                }
                String tagName = rest(args, 2);
                Tag tag = tm.get(tagName);
                if (tag == null) {
                    sender.sendMessage(plugin.msg("not-found", "%tag%", tagName));
                    return true;
                }
                tm.give(target, tag);
                sender.sendMessage(plugin.msg("given", "%player%", String.valueOf(target.getName()),
                        "%preview%", tm.preview(tag)));
            }
            case "remove", "убрать", "снять" -> {
                if (args.length < 2) {
                    sender.sendMessage(plugin.msg("usage-remove"));
                    return true;
                }
                OfflinePlayer target = findPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(plugin.msg("player-not-found", "%player%", args[1]));
                    return true;
                }
                boolean had = tm.take(target);
                sender.sendMessage(plugin.msg(had ? "removed" : "has-no-tag", "%player%", String.valueOf(target.getName())));
            }
            case "delete", "удалить" -> {
                if (args.length < 2) {
                    sender.sendMessage(plugin.msg("usage-delete"));
                    return true;
                }
                String tagName = rest(args, 1);
                Tag tag = tm.get(tagName);
                if (tag == null) {
                    sender.sendMessage(plugin.msg("not-found", "%tag%", tagName));
                    return true;
                }
                tm.delete(tag);
                sender.sendMessage(plugin.msg("deleted", "%tag%", tag.name));
            }
            case "list", "список" -> {
                List<Tag> all = tm.all();
                if (all.isEmpty()) {
                    sender.sendMessage(plugin.text("list-empty"));
                    return true;
                }
                sender.sendMessage(plugin.text("list-title"));
                for (Tag t : all) {
                    sender.sendMessage(plugin.text("list-line", "%preview%", tm.preview(t),
                            "%count%", String.valueOf(tm.holders(t))));
                }
            }
            default -> {
                sender.sendMessage(plugin.text("help-title"));
                for (String line : plugin.getConfig().getStringList("messages.help-lines")) {
                    sender.sendMessage(TagManager.LEGACY.deserialize(line));
                }
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("rutags.use")) return out;
        if (args.length == 1) {
            for (String s : new String[]{"создать", "выдать", "убрать", "удалить", "список", "reload"}) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
            return out;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        boolean give = sub.equals("выдать") || sub.equals("give");
        boolean remove = sub.equals("убрать") || sub.equals("remove");
        boolean delete = sub.equals("удалить") || sub.equals("delete");
        boolean create = sub.equals("создать") || sub.equals("create");
        if (args.length == 2 && (give || remove)) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
            }
        } else if ((args.length == 3 && give) || (args.length == 2 && (delete || create))) {
            String prefix = args[args.length - 1].toLowerCase(Locale.ROOT);
            for (Tag t : plugin.manager().all()) {
                if (t.name.toLowerCase(Locale.ROOT).startsWith(prefix)) out.add(t.name);
            }
        }
        return out;
    }
}
