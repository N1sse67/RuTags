package me.rutags;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.view.AnvilView;

public final class TagListener implements Listener {

    private final TagsPlugin plugin;

    public TagListener(TagsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        // Через секунду, чтобы Essentials успел выставить своё имя.
        Bukkit.getScheduler().runTaskLater(plugin, () -> plugin.manager().apply(p), 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.anvils().remove(e.getPlayer().getUniqueId());
    }

    /**
     * Тег в чате. Работает вместе с Essentials и другими плагинами чата: мы дописываем тег в начало
     * уже готового формата сообщения (последним, чтобы никто его не перезаписал).
     */
    @SuppressWarnings("deprecation")
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent e) {
        String prefix = plugin.manager().chatPrefix(e.getPlayer().getUniqueId());
        if (prefix.isEmpty()) return;
        e.setFormat(prefix + e.getFormat());
    }

    // ---------- меню цветов ----------

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;

        if (e.getView().getTopInventory().getHolder() instanceof ColorMenu menu) {
            e.setCancelled(true);
            if (e.getClickedInventory() == e.getView().getTopInventory()) menu.click(player, e.getSlot());
            return;
        }

        TagsPlugin.AnvilSession session = plugin.anvils().get(player.getUniqueId());
        if (session == null || e.getView().getTopInventory().getType() != InventoryType.ANVIL) return;

        e.setCancelled(true);
        if (e.getRawSlot() != 2) return;
        if (!(e.getView() instanceof AnvilView view)) return;

        String text = view.getRenameText();
        if (text == null || text.isBlank()) text = plugin.getConfig().getString("anvil-start-text", "#FFAA00");
        ColorUtil.Result res = ColorUtil.resolve(text, plugin.getConfig().getInt("max-length", 16));
        if (res == null) {
            player.sendMessage(plugin.msg("anvil-bad", "%max%", String.valueOf(plugin.getConfig().getInt("max-length", 16))));
            return;
        }
        plugin.anvils().remove(player.getUniqueId());
        e.getView().getTopInventory().clear();
        player.closeInventory();
        plugin.finish(player, session.name(), res.color(), res.display());
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ColorMenu
                || (e.getWhoClicked() instanceof Player p && plugin.anvils().containsKey(p.getUniqueId())
                && e.getView().getTopInventory().getType() == InventoryType.ANVIL)) {
            e.setCancelled(true);
        }
    }

    /** Результат в наковальне: предпросмотр тега с введённым цветом. */
    @EventHandler
    public void onPrepare(PrepareAnvilEvent e) {
        if (!(e.getView().getPlayer() instanceof Player player)) return;
        TagsPlugin.AnvilSession session = plugin.anvils().get(player.getUniqueId());
        if (session == null) return;

        String text = e.getView().getRenameText();
        if (text == null || text.isBlank()) text = plugin.getConfig().getString("anvil-start-text", "#FFAA00");
        ColorUtil.Result res = ColorUtil.resolve(text, plugin.getConfig().getInt("max-length", 16));

        ItemStack result;
        ItemMeta meta;
        if (res == null) {
            result = new ItemStack(Material.BARRIER);
            meta = result.getItemMeta();
            meta.displayName(TagManager.LEGACY.deserialize(plugin.raw("anvil-preview-bad")).decoration(TextDecoration.ITALIC, false));
        } else {
            result = new ItemStack(Material.LIME_DYE);
            meta = result.getItemMeta();
            meta.displayName(TagManager.LEGACY.deserialize(plugin.manager().preview(new Tag(session.name(), res.color(), res.display())))
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(java.util.List.of(Component.text(plugin.raw("anvil-preview-ok"))
                    .decoration(TextDecoration.ITALIC, false)));
        }
        result.setItemMeta(meta);
        e.setResult(result);
        e.getView().setRepairCost(0);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player player)) return;
        if (plugin.anvils().remove(player.getUniqueId()) != null
                && e.getInventory().getType() == InventoryType.ANVIL) {
            e.getInventory().clear();
        }
    }
}
