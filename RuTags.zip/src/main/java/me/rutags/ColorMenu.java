package me.rutags;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/** Меню выбора цвета тега (Java). Слоты 0-15 цвета, 18 жирный, 22 свой цвет, 26 отмена. */
public final class ColorMenu implements InventoryHolder {

    private final TagsPlugin plugin;
    private final String name;
    private final boolean bold;
    private Inventory inventory;

    private ColorMenu(TagsPlugin plugin, String name, boolean bold) {
        this.plugin = plugin;
        this.name = name;
        this.bold = bold;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private static Component plain(String legacy) {
        return TagManager.LEGACY.deserialize(legacy).decoration(TextDecoration.ITALIC, false);
    }

    public static void open(TagsPlugin plugin, Player player, String name, boolean bold) {
        ColorMenu menu = new ColorMenu(plugin, name, bold);
        String title = TagsPlugin.fill(plugin.raw("menu-title"), "%tag%", name);
        menu.inventory = Bukkit.createInventory(menu, 27, Component.text(title));

        for (int i = 0; i < ColorUtil.PALETTE.length; i++) {
            String[] c = ColorUtil.PALETTE[i];
            Material mat = Material.matchMaterial(c[3]);
            ItemStack stack = new ItemStack(mat == null ? Material.WHITE_WOOL : mat);
            ItemMeta meta = stack.getItemMeta();
            String color = "&" + c[0] + (bold ? "&l" : "");
            meta.displayName(plain(plugin.manager().preview(new Tag(name, color))));
            meta.lore(List.of(plain("&7" + c[1]), plain(plugin.raw("menu-lore"))));
            stack.setItemMeta(meta);
            menu.inventory.setItem(i, stack);
        }

        ItemStack b = new ItemStack(bold ? Material.ENCHANTED_BOOK : Material.BOOK);
        ItemMeta bm = b.getItemMeta();
        bm.displayName(plain(plugin.raw(bold ? "menu-bold-on" : "menu-bold-off")));
        bm.lore(List.of(plain(plugin.raw("menu-bold-lore"))));
        b.setItemMeta(bm);
        menu.inventory.setItem(18, b);

        ItemStack custom = new ItemStack(Material.ANVIL);
        ItemMeta cm = custom.getItemMeta();
        cm.displayName(plain(plugin.raw("menu-custom")));
        cm.lore(List.of(plain(plugin.raw("menu-custom-lore"))));
        custom.setItemMeta(cm);
        menu.inventory.setItem(22, custom);

        ItemStack cancel = new ItemStack(Material.BARRIER);
        ItemMeta xm = cancel.getItemMeta();
        xm.displayName(plain(plugin.raw("menu-cancel")));
        cancel.setItemMeta(xm);
        menu.inventory.setItem(26, cancel);

        player.openInventory(menu.inventory);
    }

    public void click(Player player, int slot) {
        if (slot >= 0 && slot < ColorUtil.PALETTE.length) {
            String color = "&" + ColorUtil.PALETTE[slot][0] + (bold ? "&l" : "");
            player.closeInventory();
            plugin.finish(player, name, color);
        } else if (slot == 18) {
            open(plugin, player, name, !bold);
        } else if (slot == 22) {
            player.closeInventory();
            Bukkit.getScheduler().runTask(plugin, () -> plugin.openAnvil(player, name));
        } else if (slot == 26) {
            player.closeInventory();
        }
    }
}
