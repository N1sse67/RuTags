package me.rutags;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Список цветов и разбор цвета, написанного вручную. */
final class ColorUtil {

    private ColorUtil() {
    }

    /** код, русское название, английское название, предмет в меню. */
    static final String[][] PALETTE = {
            {"0", "Чёрный", "black", "BLACK_CONCRETE"},
            {"1", "Тёмно-синий", "dark_blue", "BLUE_CONCRETE"},
            {"2", "Тёмно-зелёный", "dark_green", "GREEN_CONCRETE"},
            {"3", "Бирюзовый", "dark_aqua", "CYAN_CONCRETE"},
            {"4", "Тёмно-красный", "dark_red", "RED_CONCRETE"},
            {"5", "Фиолетовый", "dark_purple", "PURPLE_CONCRETE"},
            {"6", "Золотой", "gold", "ORANGE_CONCRETE"},
            {"7", "Серый", "gray", "LIGHT_GRAY_CONCRETE"},
            {"8", "Тёмно-серый", "dark_gray", "GRAY_CONCRETE"},
            {"9", "Синий", "blue", "LAPIS_BLOCK"},
            {"a", "Зелёный", "green", "LIME_CONCRETE"},
            {"b", "Голубой", "aqua", "LIGHT_BLUE_CONCRETE"},
            {"c", "Красный", "red", "REDSTONE_BLOCK"},
            {"d", "Розовый", "light_purple", "PINK_CONCRETE"},
            {"e", "Жёлтый", "yellow", "YELLOW_CONCRETE"},
            {"f", "Белый", "white", "WHITE_CONCRETE"},
    };

    /** Результат ввода: одноцветный (color) или разноцветный текст (display). */
    record Result(String color, String display) {}

    private static final Pattern CODE = Pattern.compile("&#[0-9a-f]{6}|&[0-9a-fl-o]");

    /** Разбирает ввод: либо один цвет, либо готовый текст с цветами (&6А&7д&8м&9и&0н). null, если не вышло. */
    static Result resolve(String input, int maxLength) {
        String color = parse(input);
        if (color != null) return new Result(color, null);
        String rich = parseRich(input, maxLength);
        return rich == null ? null : new Result("&f", rich);
    }

    /** Текст с цветовыми кодами. Нужен хотя бы один код и от 1 до maxLength видимых символов. */
    static String parseRich(String input, int maxLength) {
        if (input == null) return null;
        String s = input.trim().replace('§', '&');
        s = s.replaceAll("(?i)(?<!&)#([0-9a-f]{6})", "&#$1");
        s = CODE.matcher(s).replaceAll(m -> m.group().toLowerCase(Locale.ROOT));
        Matcher m = CODE.matcher(s);
        int codes = 0;
        while (m.find()) codes++;
        String plain = CODE.matcher(s).replaceAll("");
        if (codes == 0 || plain.isEmpty() || plain.length() > maxLength) return null;
        if (plain.contains("&")) return null; // остался неизвестный код, например &k
        return s;
    }

    private static final Pattern TOKEN = Pattern.compile("&?#?([0-9a-f]{6})|&([0-9a-fl-o])");

    /**
     * Разбирает цвет: #FF8800, ff8800, &6, &c&l, "красный", "red" (можно с " жирный" не нужно).
     * Возвращает нормализованную запись (&#ff8800&l) или null, если не получилось.
     */
    static String parse(String input) {
        if (input == null) return null;
        String s = input.trim().toLowerCase(Locale.ROOT).replace('§', '&');
        if (s.isEmpty()) return null;

        for (String[] c : PALETTE) {
            if (s.equals(c[1].toLowerCase(Locale.ROOT)) || s.equals(c[2]) || s.equals(c[2].replace("_", " "))) {
                return "&" + c[0];
            }
        }
        if (s.length() == 1 && "0123456789abcdef".contains(s)) return "&" + s;

        s = s.replace(" ", "");
        Matcher m = TOKEN.matcher(s);
        StringBuilder out = new StringBuilder();
        boolean hasColor = false;
        int pos = 0;
        while (pos < s.length()) {
            m.region(pos, s.length());
            if (!m.lookingAt()) return null;
            if (m.group(1) != null) {
                out.append("&#").append(m.group(1));
                hasColor = true;
            } else {
                String code = m.group(2);
                out.append('&').append(code);
                if ("0123456789abcdef".contains(code)) hasColor = true;
            }
            pos = m.end();
        }
        return hasColor ? out.toString() : null;
    }
}
