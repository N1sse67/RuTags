package me.rutags;

/** Тег: текст и цвет (например "&#ff8800&l"). */
public final class Tag {
    public String name;
    public String color;
    /** Если задан, показывается вместо цвета+названия: полный текст с цветами, например &6А&7д&8м. */
    public String display;

    public Tag(String name, String color) {
        this(name, color, null);
    }

    public Tag(String name, String color, String display) {
        this.name = name;
        this.color = color;
        this.display = display;
    }
}
