package me.rutags;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Хранение тегов и их показ возле ника. */
public final class TagManager {

    static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private final TagsPlugin plugin;
    private final File file;
    private final Map<String, Tag> tags = new ConcurrentHashMap<>();
    private final Map<UUID, String> assigned = new ConcurrentHashMap<>();

    public TagManager(TagsPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    private static String key(String name) {
        return name.toLowerCase(Locale.ROOT);
    }

    // ---------- хранение ----------

    public void load() {
        tags.clear();
        assigned.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection t = yml.getConfigurationSection("tags");
        if (t != null) {
            for (String k : t.getKeys(false)) {
                String name = t.getString(k + ".name", k);
                String color = t.getString(k + ".color", "&f");
                String display = t.getString(k + ".display", null);
                tags.put(key(name), new Tag(name, color, display));
            }
        }
        ConfigurationSection p = yml.getConfigurationSection("players");
        if (p != null) {
            for (String id : p.getKeys(false)) {
                try {
                    String tagKey = p.getString(id, "");
                    if (tags.containsKey(tagKey)) assigned.put(UUID.fromString(id), tagKey);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        int i = 0;
        for (Tag t : tags.values()) {
            String b = "tags.t" + (i++);
            yml.set(b + ".name", t.name);
            yml.set(b + ".color", t.color);
            if (t.display != null) yml.set(b + ".display", t.display);
        }
        for (Map.Entry<UUID, String> e : assigned.entrySet()) {
            yml.set("players." + e.getKey(), e.getValue());
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить data.yml: " + e.getMessage());
        }
    }

    // ---------- теги ----------

    public Tag get(String name) {
        return tags.get(key(name));
    }

    public List<Tag> all() {
        List<Tag> list = new ArrayList<>(tags.values());
        list.sort(Comparator.comparing(t -> key(t.name)));
        return list;
    }

    public Tag tagOf(UUID uuid) {
        String k = assigned.get(uuid);
        return k == null ? null : tags.get(k);
    }

    public int holders(Tag tag) {
        int n = 0;
        for (String k : assigned.values()) if (k.equals(key(tag.name))) n++;
        return n;
    }

    /** Создать тег или обновить цвет у существующего. Возвращает true, если тег уже был. */
    public boolean createOrUpdate(String name, String color, String display) {
        boolean existed = tags.containsKey(key(name));
        Tag tag = existed ? tags.get(key(name)) : new Tag(name, color, display);
        tag.color = color;
        tag.display = display;
        tags.put(key(name), tag);
        save();
        refreshHolders(tag);
        return existed;
    }

    public void delete(Tag tag) {
        String k = key(tag.name);
        List<UUID> holders = new ArrayList<>();
        for (Map.Entry<UUID, String> e : assigned.entrySet()) if (e.getValue().equals(k)) holders.add(e.getKey());
        tags.remove(k);
        for (UUID id : holders) {
            assigned.remove(id);
            Player p = Bukkit.getPlayer(id);
            if (p != null) apply(p);
        }
        save();
    }

    public void give(OfflinePlayer target, Tag tag) {
        assigned.put(target.getUniqueId(), key(tag.name));
        save();
        Player online = target.getPlayer();
        if (online != null) apply(online);
    }

    /** Снять тег. Возвращает false, если тега не было. */
    public boolean take(OfflinePlayer target) {
        boolean had = assigned.remove(target.getUniqueId()) != null;
        save();
        Player online = target.getPlayer();
        if (online != null) apply(online);
        return had;
    }

    private void refreshHolders(Tag tag) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            Tag t = tagOf(p.getUniqueId());
            if (t != null && t == tag) apply(p);
        }
    }

    // ---------- отображение ----------

    public String format(Tag tag) {
        return plugin.getConfig().getString("format", "&8[%tag%&8] &r")
                .replace("%tag%", tag.display != null ? tag.display : tag.color + tag.name);
    }

    /** Красивая запись тега для сообщений. */
    public String preview(Tag tag) {
        return format(tag).replace("&r", "").trim();
    }

    private static final LegacyComponentSerializer SECTION = LegacyComponentSerializer.builder()
            .character('§').hexColors().useUnusualXRepeatedCharacterHexFormat().build();

    /** Тег для чата: строка с цветами в формате §, которая ставится перед форматом сообщения. Пусто, если тега нет. */
    public String chatPrefix(UUID uuid) {
        Tag tag = tagOf(uuid);
        if (tag == null) return "";
        return SECTION.serialize(LEGACY.deserialize(format(tag))).replace("%", "%%");
    }

    private static String teamName(Player player) {
        return "rt_" + player.getUniqueId().toString().replace("-", "").substring(0, 12);
    }

    private Scoreboard board() {
        return Bukkit.getScoreboardManager().getMainScoreboard();
    }

    private void removeTeam(Player player) {
        Team team = board().getTeam(teamName(player));
        if (team != null) team.unregister();
    }

    /** Показать (или убрать) тег над головой и в списке игроков. В чате тег ставит слушатель чата. */
    public void apply(Player player) {
        Tag tag = tagOf(player.getUniqueId());
        if (tag == null) {
            removeTeam(player);
            if (touched.remove(player.getUniqueId())) player.playerListName(null);
            return;
        }
        touched.add(player.getUniqueId());
        Component prefix = LEGACY.deserialize(format(tag));
        if (plugin.getConfig().getBoolean("nameplate", true)) {
            Team team = board().getTeam(teamName(player));
            if (team == null) team = board().registerNewTeam(teamName(player));
            team.prefix(prefix);
            team.addEntry(player.getName());
            player.playerListName(null);
        } else {
            removeTeam(player);
            player.playerListName(prefix.append(Component.text(player.getName())));
        }
    }

    private final java.util.Set<UUID> touched = ConcurrentHashMap.newKeySet();

    /** Раз в несколько секунд: вернуть тег над головой, если другой плагин убрал игрока из нашей команды. */
    public void tick() {
        if (!plugin.getConfig().getBoolean("nameplate", true)) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (tagOf(p.getUniqueId()) == null) continue;
            Team team = board().getTeam(teamName(p));
            if (team == null || !team.hasEntry(p.getName())) apply(p);
        }
    }

    public void applyAll() {
        for (Player p : Bukkit.getOnlinePlayers()) apply(p);
    }

    /** При выключении убираем наши команды, чтобы они не остались в мире. */
    public void cleanup() {
        for (Team team : new ArrayList<>(board().getTeams())) {
            if (team.getName().startsWith("rt_")) team.unregister();
        }
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (touched.contains(p.getUniqueId())) p.playerListName(null);
        }
    }
}
