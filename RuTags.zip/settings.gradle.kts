rootProject.name = "RuTags"
